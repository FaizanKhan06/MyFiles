package com.demo.testing.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.demo.testing.entity.TestEntity;
import com.demo.testing.repo.TestRepo;

@Service
public class TestService {

    @Autowired
    TestRepo repo;

    public TestEntity getATest(int id) {
        return repo.findById(id).orElse(null);
    }

    public List<TestEntity> getAllTest() {
        return repo.findAll();
    }

    public TestEntity addTest(TestEntity test) {
        return repo.saveAndFlush(test);
    }

    public TestEntity updateTest(TestEntity test) {
        return repo.save(test);
    }

    public void deleteTest(int id) {
        repo.deleteById(id);
    }

}
