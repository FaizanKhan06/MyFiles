package com.money_tracker.auth_service.service;

import java.time.LocalDateTime;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Service;

import com.money_tracker.auth_service.dao.UserCredentialsDao;
import com.money_tracker.auth_service.dao.entity.UserCredentialsEntity;
import com.money_tracker.auth_service.pojo.UserInputPojo;

@Service
public class UserCredentialsService {
    @Autowired
    JwtService jwtService;

    @Autowired
    UserCredentialsDao authDao;

    @Autowired
    private PasswordEncoder passwordEncoder;

    public UserCredentialsEntity register(UserInputPojo user) {
        UserCredentialsEntity newUser = new UserCredentialsEntity();
        newUser.setEmail(user.getEmail());
        newUser.setPassword(passwordEncoder.encode(user.getPassword()));
        newUser.setName(user.getName());
        newUser.setCreatedAt(LocalDateTime.now());
        newUser.setUpdatedAt(LocalDateTime.now());
        return authDao.saveAndFlush(newUser);
    }

    public String generateToken(String name) {
        return jwtService.generateToken(name);
    }

    public boolean verifyToken(String token) {
        return jwtService.validateToken(token);
    }
}